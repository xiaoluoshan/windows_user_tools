When you install the program, you will find a "template.ini" file in the language folder of the installation folder.(template.ini = English.ini)
Be able to translate the language-specific filename should be named as follows:

Bulgarian.ini
Catalan.ini
ChineseTraditional.ini
Croatian.ini
Czech.ini
Danish.ini
Dutch.ini
English.ini
Finnish.ini
French.ini
German.ini
Greek.ini
Georgian.ini
Hungarian.ini
Italian.ini
Japanese.ini
korean.ini
Norwegian.ini
Polish.ini
Portuguese.ini
Russian.ini
Slovak.ini
Slovenian.ini
Spanish.ini
Uzbek.ini
....etc..


1. Change the name as a language to translate template.ini 
2. Run the program, check the language settings.
3. Your language has been added.
4. Select your language, and restart program.
5. By editing the ini file, you can determine whether the applicable language.
6. Translation has been completed, please send the ini file admin@ohsoft.net.

[Note]
Translated word is longer than the screen, and the screen so you can stretch or break and must be replaced with an appropriate short word.
Tell us if you're a difficult part to handle.

Thanks.